Buildplan PC Planner

Open index.html in Chrome or another modern browser.
The landing page Build Now buttons open the PC parts planner.
Planning works without an account; the account prototype is only used when saving builds.
Prices are estimates and may differ from retailer listings.
